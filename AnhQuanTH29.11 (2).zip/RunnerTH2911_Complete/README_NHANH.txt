RUNNER 3D — TH29.11 — HƯỚNG DẪN NHANH
1. Unity Hub > New project > 3D (Core).
2. Đóng Unity Editor.
3. Chép thư mục Assets trong gói này vào thư mục project.
4. Mở lại project và chờ import.
5. Trên thanh menu Unity chọn Tools > TH29.11 > Create Runner Scene.
6. Mở Assets/Scenes/Runner3D.unity nếu chưa tự mở.
7. Nhấn Play, sau đó bấm START.
Điều khiển: A/← trái; D/→ phải; Space nhảy; Esc tạm dừng; R chơi lại khi Game Over.
Báo cáo: BaoCao_DoAn_TH29.11.txt
Quan trọng: đây là project source, không phải file .exe. Cần kiểm thử trong Unity và bổ sung ảnh chụp màn hình trước khi nộp.

NEU BAN PHIM KHONG HOAT DONG:
Edit > Project Settings > Player > Other Settings > Active Input Handling
chọn Both (hoặc Input Manager (Old)), rồi khởi động lại Unity.
