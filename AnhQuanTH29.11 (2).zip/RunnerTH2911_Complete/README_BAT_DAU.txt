RUNNER 3D — ĐỒ ÁN TH29.11
BẢN DỰNG TỰ ĐỘNG SCENE CHO UNITY

CÁCH DÙNG:
1. Tạo project mới trong Unity Hub bằng template 3D (Core).
2. Đóng Unity Editor.
3. Chép thư mục Assets từ gói này vào thư mục project (chọn Merge/Replace nếu được hỏi).
4. Mở lại project trong Unity và đợi import.
5. Trên menu Unity chọn Tools > TH29.11 > Create Runner Scene.
6. Scene tự tạo sẽ được lưu tại Assets/Scenes/Runner3D.unity.
7. Mở scene Assets/Scenes/Runner3D.unity, nhấn Play.
8. Bấm nút START trong game.
ĐIỀU KHIỂN: A/← đổi làn trái; D/→ đổi làn phải; Space nhảy; Esc tạm dừng; R chơi lại sau Game Over.

GHI CHÚ:
- Scene được tạo bằng editor script, vì vậy cần mở trong Unity Editor để chạy menu Tools.
- Đã hướng tới Built-in Render Pipeline và UI Text cổ điển để giảm phụ thuộc package.
- Cần kiểm thử trên phiên bản Unity bạn cài. Đây không phải file .exe đã build sẵn.
- Trước khi nộp, bổ sung tên sinh viên, lớp, ảnh chụp màn hình sản phẩm thực tế và xác nhận yêu cầu của giảng viên.
