#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using System.IO;

public static class RunnerSceneBuilder
{
    [MenuItem("Tools/TH29.11/Create Runner Scene")]
    public static void CreateScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        RenderSettings.ambientLight = new Color(0.65f, 0.68f, 0.72f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.68f, 0.78f, 0.88f);
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogStartDistance = 35f;
        RenderSettings.fogEndDistance = 150f;

        Material roadMat = MakeMat("Road_Material", new Color(0.16f, 0.19f, 0.23f));
        Material laneMat = MakeMat("Lane_Material", new Color(0.9f, 0.9f, 0.8f));
        Material grassMat = MakeMat("Grass_Material", new Color(0.22f, 0.48f, 0.28f));
        Material playerMat = MakeMat("Player_Material", new Color(0.1f, 0.55f, 0.95f));
        Material coinMat = MakeMat("Coin_Material", new Color(1f, 0.72f, 0.05f));
        Material obstacleMat = MakeMat("Obstacle_Material", new Color(0.9f, 0.18f, 0.12f));

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Road";
        ground.transform.position = new Vector3(0, -0.15f, 55);
        ground.transform.localScale = new Vector3(8.5f, 0.3f, 140f);
        ground.GetComponent<Renderer>().sharedMaterial = roadMat;

        GameObject leftGrass = GameObject.CreatePrimitive(PrimitiveType.Cube);
        leftGrass.name = "Left_Ground";
        leftGrass.transform.position = new Vector3(-8f, -0.25f, 55);
        leftGrass.transform.localScale = new Vector3(7.5f, 0.2f, 140f);
        leftGrass.GetComponent<Renderer>().sharedMaterial = grassMat;
        GameObject rightGrass = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rightGrass.name = "Right_Ground";
        rightGrass.transform.position = new Vector3(8f, -0.25f, 55);
        rightGrass.transform.localScale = new Vector3(7.5f, 0.2f, 140f);
        rightGrass.GetComponent<Renderer>().sharedMaterial = grassMat;

        for (int z = 0; z < 140; z += 8)
        {
            CreateCube("LaneDash_Left", new Vector3(-1.2f, 0.02f, z + 4), new Vector3(0.08f, 0.03f, 3f), laneMat, false);
            CreateCube("LaneDash_Right", new Vector3(1.2f, 0.02f, z + 4), new Vector3(0.08f, 0.03f, 3f), laneMat, false);
        }

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player";
        player.transform.position = new Vector3(0, 1.05f, 0);
        player.GetComponent<Renderer>().sharedMaterial = playerMat;
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = 0.38f; cc.center = new Vector3(0, 0, 0);
        player.AddComponent<RunnerPlayer>();

        GameObject cameraGO = new GameObject("Main Camera");
        cameraGO.tag = "MainCamera";
        Camera cam = cameraGO.AddComponent<Camera>();
        cam.fieldOfView = 65;
        cameraGO.AddComponent<AudioListener>();
        RunnerCamera follow = cameraGO.AddComponent<RunnerCamera>();
        follow.target = player.transform;
        cameraGO.transform.position = new Vector3(0, 5, -8);

        GameObject lightGO = new GameObject("Directional Light");
        Light light = lightGO.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.15f;
        lightGO.transform.rotation = Quaternion.Euler(45, -25, 0);

        GameObject managerGO = new GameObject("GameManager");
        RunnerGameManager manager = managerGO.AddComponent<RunnerGameManager>();

        GameObject spawnerGO = new GameObject("RunnerSpawner");
        RunnerSpawner spawner = spawnerGO.AddComponent<RunnerSpawner>();
        spawner.player = player.transform;
        spawner.obstacleMaterial = obstacleMat;
        spawner.coinMaterial = coinMat;

        // UI
        GameObject canvasGO = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasGO.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasGO.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280, 720);

        GameObject eventGO = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        Text score = CreateText(canvasGO.transform, "ScoreLabel", "ĐIỂM: 0", 28, TextAnchor.UpperLeft, new Vector2(0,1), new Vector2(0,1), new Vector2(24,-22), new Vector2(300,60));
        Text status = CreateText(canvasGO.transform, "StatusLabel", "", 28, TextAnchor.MiddleCenter, new Vector2(.5f,.5f), new Vector2(.5f,.5f), Vector2.zero, new Vector2(800,180));
        status.fontStyle = FontStyle.Bold;

        GameObject startPanel = CreatePanel(canvasGO.transform, "StartPanel", new Color(0.02f,0.04f,0.08f,0.82f));
        Text title = CreateText(startPanel.transform, "Title", "RUNNER 3D", 54, TextAnchor.MiddleCenter, new Vector2(.5f,.72f), new Vector2(.5f,.72f), Vector2.zero, new Vector2(900,90));
        title.fontStyle = FontStyle.Bold;
        Text subtitle = CreateText(startPanel.transform, "Subtitle", "Chạy, né chướng ngại vật và thu thập xu!", 24, TextAnchor.MiddleCenter, new Vector2(.5f,.58f), new Vector2(.5f,.58f), Vector2.zero, new Vector2(900,50));
        CreateButton(startPanel.transform, "StartButton", "START", new Vector2(.5f,.40f), new Vector2(220,70), manager, true);
        Text controls = CreateText(startPanel.transform, "Controls", "A/D hoặc ←/→: đổi làn     SPACE: nhảy     ESC: tạm dừng", 20, TextAnchor.MiddleCenter, new Vector2(.5f,.25f), new Vector2(.5f,.25f), Vector2.zero, new Vector2(1000,50));

        GameObject overPanel = CreatePanel(canvasGO.transform, "GameOverPanel", new Color(0.02f,0.04f,0.08f,0.88f));
        Text overTitle = CreateText(overPanel.transform, "GameOverTitle", "GAME OVER", 52, TextAnchor.MiddleCenter, new Vector2(.5f,.68f), new Vector2(.5f,.68f), Vector2.zero, new Vector2(900,90));
        overTitle.fontStyle = FontStyle.Bold;
        Text finalScore = CreateText(overPanel.transform, "FinalScore", "Điểm của bạn: 0", 30, TextAnchor.MiddleCenter, new Vector2(.5f,.52f), new Vector2(.5f,.52f), Vector2.zero, new Vector2(700,60));
        CreateButton(overPanel.transform, "RestartButton", "CHƠI LẠI", new Vector2(.5f,.35f), new Vector2(240,70), manager, false);
        overPanel.SetActive(false);

        manager.scoreLabel = score;
        manager.statusLabel = status;
        manager.startPanel = startPanel;
        manager.gameOverPanel = overPanel;
        manager.finalScoreLabel = finalScore;

        string sceneDir = "Assets/Scenes";
        if (!AssetDatabase.IsValidFolder(sceneDir)) AssetDatabase.CreateFolder("Assets", "Scenes");
        EditorSceneManager.SaveScene(scene, sceneDir + "/Runner3D.unity");
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = player;
        EditorUtility.DisplayDialog("TH29.11 - Runner 3D", "Đã tạo scene tại Assets/Scenes/Runner3D.unity.\nMở scene và nhấn Play để kiểm thử.", "OK");
    }

    static Material MakeMat(string name, Color color)
    {
        string path = "Assets/" + name + ".mat";
        Material m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (!m) {
            Shader s = Shader.Find("Standard");
            if (s == null) s = Shader.Find("Universal Render Pipeline/Lit");
            m = new Material(s);
            AssetDatabase.CreateAsset(m, path);
        }
        m.color = color;
        EditorUtility.SetDirty(m);
        return m;
    }

    static GameObject CreateCube(string name, Vector3 pos, Vector3 scale, Material mat, bool collider)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name; go.transform.position = pos; go.transform.localScale = scale;
        if (mat) go.GetComponent<Renderer>().sharedMaterial = mat;
        if (!collider) Object.DestroyImmediate(go.GetComponent<Collider>());
        return go;
    }

    static GameObject CreatePanel(Transform parent, string name, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        go.GetComponent<Image>().color = color;
        return go;
    }

    static Text CreateText(Transform parent, string name, string value, int size, TextAnchor anchor, Vector2 amin, Vector2 amax, Vector2 pos, Vector2 dims)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = amin; rt.anchorMax = amax; rt.anchoredPosition = pos; rt.sizeDelta = dims;
        Text t = go.GetComponent<Text>();
        t.text = value; t.font = Resources.GetBuiltinResource<Font>("Arial.ttf"); t.fontSize = size; t.alignment = anchor;
        t.color = Color.white; t.horizontalOverflow = HorizontalWrapMode.Wrap; t.verticalOverflow = VerticalWrapMode.Overflow;
        return t;
    }

    static void CreateButton(Transform parent, string name, string label, Vector2 anchor, Vector2 size, RunnerGameManager manager, bool isStart)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.anchoredPosition = Vector2.zero; rt.sizeDelta = size;
        Image img = go.GetComponent<Image>(); img.color = new Color(0.08f,0.48f,0.85f,1f);
        Button button = go.GetComponent<Button>();
        RunnerUIButton buttonAction = go.AddComponent<RunnerUIButton>();
        buttonAction.manager = manager;
        buttonAction.isStartButton = isStart;
        button.onClick.AddListener(buttonAction.Click);
        Text text = CreateText(go.transform, "Label", label, 25, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        RectTransform tr = text.GetComponent<RectTransform>(); tr.offsetMin = Vector2.zero; tr.offsetMax = Vector2.zero;
    }
}
#endif
