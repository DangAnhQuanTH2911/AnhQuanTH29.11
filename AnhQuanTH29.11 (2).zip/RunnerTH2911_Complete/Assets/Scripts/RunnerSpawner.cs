using UnityEngine;
using System.Collections.Generic;

public class RunnerSpawner : MonoBehaviour
{
    public Transform player;
    public int rowsAhead = 12;
    public float rowSpacing = 8f;
    public float laneDistance = 2.4f;
    public float spawnAheadDistance = 90f;
    public float cleanupBehindDistance = 18f;
    public Material obstacleMaterial;
    public Material coinMaterial;

    readonly List<GameObject> spawned = new List<GameObject>();
    float nextZ;

    void Start() { ResetSpawner(); }

    void Update()
    {
        var gm = RunnerGameManager.Instance;
        if (!player || gm == null || !gm.Playing || gm.IsOver || gm.IsPaused) return;
        while (nextZ < player.position.z + spawnAheadDistance)
        {
            SpawnRow(nextZ);
            nextZ += rowSpacing;
        }
        for (int i = spawned.Count - 1; i >= 0; i--)
        {
            if (spawned[i] == null) { spawned.RemoveAt(i); continue; }
            if (spawned[i].transform.position.z < player.position.z - cleanupBehindDistance)
            {
                Destroy(spawned[i]);
                spawned.RemoveAt(i);
            }
        }
    }

    public void ResetSpawner()
    {
        foreach (GameObject go in spawned) if (go) Destroy(go);
        spawned.Clear();
        nextZ = player ? player.position.z + 14f : 14f;
    }

    void SpawnRow(float z)
    {
        int obstacleLane = Random.Range(0, 3);
        int coinLane = (obstacleLane + Random.Range(1, 3)) % 3;
        if (Random.value < 0.8f)
        {
            GameObject obstacle = GameObject.CreatePrimitive(PrimitiveType.Cube);
            obstacle.name = "Obstacle";
            obstacle.transform.position = new Vector3((obstacleLane - 1) * laneDistance, 0.65f, z);
            obstacle.transform.localScale = new Vector3(1.25f, 1.3f, 1f);
            obstacle.tag = "Obstacle";
            Collider c = obstacle.GetComponent<Collider>();
            c.isTrigger = true;
            Rigidbody rb = obstacle.AddComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            obstacle.AddComponent<RunnerObstacle>();
            if (obstacleMaterial) obstacle.GetComponent<Renderer>().material = obstacleMaterial;
            spawned.Add(obstacle);
        }

        for (int j = 0; j < 2; j++)
        {
            GameObject coin = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            coin.name = "Coin";
            coin.transform.position = new Vector3((coinLane - 1) * laneDistance, 1.2f, z + j * 1.4f);
            coin.transform.localScale = Vector3.one * 0.55f;
            Collider c = coin.GetComponent<Collider>();
            c.isTrigger = true;
            Rigidbody rb = coin.AddComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            coin.AddComponent<RunnerCoin>();
            if (coinMaterial) coin.GetComponent<Renderer>().material = coinMaterial;
            spawned.Add(coin);
        }
    }
}
