using UnityEngine;

public class RunnerCoin : MonoBehaviour
{
    public int value = 1;
    void Update() { transform.Rotate(0, 120f * Time.deltaTime, 0, Space.World); }
    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<RunnerPlayer>() != null)
        {
            if (RunnerGameManager.Instance) RunnerGameManager.Instance.AddCoin(value);
            Destroy(gameObject);
        }
    }
}
