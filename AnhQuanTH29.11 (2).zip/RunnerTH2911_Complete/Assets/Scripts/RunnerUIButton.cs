using UnityEngine;

public class RunnerUIButton : MonoBehaviour
{
    public RunnerGameManager manager;
    public bool isStartButton;

    public void Click()
    {
        if (!manager) manager = FindObjectOfType<RunnerGameManager>();
        if (!manager) return;
        if (isStartButton) manager.StartGame();
        else manager.Restart();
    }
}
