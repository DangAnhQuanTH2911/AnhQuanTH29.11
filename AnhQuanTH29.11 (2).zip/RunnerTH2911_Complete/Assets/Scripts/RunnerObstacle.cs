using UnityEngine;

public class RunnerObstacle : MonoBehaviour
{
    void Awake() { gameObject.tag = "Obstacle"; }
    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<RunnerPlayer>() && RunnerGameManager.Instance)
            RunnerGameManager.Instance.EndGame();
    }
}
