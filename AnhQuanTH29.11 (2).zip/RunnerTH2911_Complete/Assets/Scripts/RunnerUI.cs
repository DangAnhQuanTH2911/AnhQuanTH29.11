using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class RunnerUI : MonoBehaviour
{
    public RunnerGameManager manager;
    public Text scoreLabel;
    public Text statusLabel;
    public Text finalScoreLabel;
    public GameObject startPanel;
    public GameObject gameOverPanel;

    void Awake()
    {
        if (!manager) manager = FindObjectOfType<RunnerGameManager>();
        if (manager)
        {
            manager.scoreLabel = scoreLabel;
            manager.statusLabel = statusLabel;
            manager.finalScoreLabel = finalScoreLabel;
            manager.startPanel = startPanel;
            manager.gameOverPanel = gameOverPanel;
        }
    }
}
