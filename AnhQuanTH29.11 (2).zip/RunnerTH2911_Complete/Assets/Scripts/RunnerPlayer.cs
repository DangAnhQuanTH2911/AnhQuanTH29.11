using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class RunnerPlayer : MonoBehaviour
{
    public float forwardSpeed = 8f;
    public float laneDistance = 2.4f;
    public float laneChangeSpeed = 12f;
    public float jumpVelocity = 8f;
    public float gravity = -22f;

    CharacterController controller;
    int lane = 1;
    float yVelocity;
    Vector3 initialPosition;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        initialPosition = transform.position;
    }

    void Update()
    {
        var gm = RunnerGameManager.Instance;
        if (gm == null || !gm.Playing || gm.IsOver || gm.IsPaused) return;

        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A))
            lane = Mathf.Max(0, lane - 1);
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D))
            lane = Mathf.Min(2, lane + 1);

        if (controller.isGrounded && yVelocity < 0) yVelocity = -2f;
        if ((Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow)) && controller.isGrounded)
            yVelocity = jumpVelocity;

        yVelocity += gravity * Time.deltaTime;
        float targetX = (lane - 1) * laneDistance;
        float xSpeed = (targetX - transform.position.x) * laneChangeSpeed;
        controller.Move(new Vector3(xSpeed, yVelocity, forwardSpeed) * Time.deltaTime);
    }

    public void ResetPlayer()
    {
        lane = 1;
        yVelocity = 0;
        controller.enabled = false;
        transform.position = initialPosition;
        controller.enabled = true;
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.collider.CompareTag("Obstacle") && RunnerGameManager.Instance != null)
            RunnerGameManager.Instance.EndGame();
    }
}
