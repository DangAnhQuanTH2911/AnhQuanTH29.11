using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class RunnerGameManager : MonoBehaviour
{
    public static RunnerGameManager Instance { get; private set; }
    public Text scoreLabel;
    public Text statusLabel;
    public GameObject startPanel;
    public GameObject gameOverPanel;
    public Text finalScoreLabel;

    public bool Playing { get; private set; }
    public bool IsOver { get; private set; }
    public bool IsPaused { get; private set; }
    int coins;
    float startTime;
    float distancePoints;

    public int Score => coins * 10 + Mathf.FloorToInt(distancePoints);

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        Time.timeScale = 1f;
    }

    void Start()
    {
        Playing = false;
        if (startPanel) startPanel.SetActive(true);
        if (gameOverPanel) gameOverPanel.SetActive(false);
        if (statusLabel) statusLabel.text = "RUNNER 3D\nA/D hoặc ←/→: đổi làn\nSPACE: nhảy";
        RefreshScore();
    }

    void Update()
    {
        if (Playing && !IsOver && !IsPaused)
        {
            distancePoints += Time.deltaTime * 2f;
            RefreshScore();
        }
        if (Playing && !IsOver && Input.GetKeyDown(KeyCode.Escape))
            TogglePause();
        if (IsOver && Input.GetKeyDown(KeyCode.R))
            Restart();
    }

    public void StartGame()
    {
        coins = 0;
        distancePoints = 0;
        startTime = Time.time;
        IsOver = false;
        IsPaused = false;
        Playing = true;
        Time.timeScale = 1f;
        if (startPanel) startPanel.SetActive(false);
        if (gameOverPanel) gameOverPanel.SetActive(false);
        if (statusLabel) statusLabel.text = "";
        RefreshScore();
        RunnerPlayer player = FindObjectOfType<RunnerPlayer>();
        if (player) player.ResetPlayer();
        RunnerSpawner spawner = FindObjectOfType<RunnerSpawner>();
        if (spawner) spawner.ResetSpawner();
    }

    public void AddCoin(int value)
    {
        if (!Playing || IsOver) return;
        coins += value;
        RefreshScore();
    }

    public void EndGame()
    {
        if (IsOver || !Playing) return;
        IsOver = true;
        Playing = false;
        Time.timeScale = 1f;
        if (gameOverPanel) gameOverPanel.SetActive(true);
        if (finalScoreLabel) finalScoreLabel.text = "Điểm của bạn: " + Score;
        if (statusLabel) statusLabel.text = "GAME OVER";
    }

    public void TogglePause()
    {
        if (!Playing || IsOver) return;
        IsPaused = !IsPaused;
        Time.timeScale = IsPaused ? 0f : 1f;
        if (statusLabel) statusLabel.text = IsPaused ? "TẠM DỪNG\nNhấn ESC để tiếp tục" : "";
    }

    public void Restart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void RefreshScore()
    {
        if (scoreLabel) scoreLabel.text = "ĐIỂM: " + Score;
    }
}
